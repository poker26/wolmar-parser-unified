# Historical Recipes Parser

Парсер исторических рецептов напитков из старинных источников с поддержкой Google Docs.

## Функциональность

- Извлечение рецептов из Google Docs
- Парсинг исторических единиц измерения
- Конвертация в современные единицы
- Сохранение в PostgreSQL базу данных
- Поддержка различных форматов URL Google Docs

## Установка

```bash
npm install
```

## Настройка

1. Создайте файл `.env` в корне проекта:
```env
DB_HOST=your-host
DB_NAME=your-database
DB_USER=your-username
DB_PASSWORD=your-password
DB_SSL=true (если используете SSL)
```

## Использование

### Основной скрипт (с параметрами)

```bash
# Использование с URL Google Docs
node run_with_url.js "https://docs.google.com/document/d/DOCUMENT_ID/edit"

# Использование с опциями
node run_with_url.js --url "https://docs.google.com/document/d/DOCUMENT_ID/view"

# Показать справку
node run_with_url.js --help
```

### Поддерживаемые форматы URL

- `https://docs.google.com/document/d/DOCUMENT_ID/edit`
- `https://docs.google.com/document/d/DOCUMENT_ID/view`
- `https://docs.google.com/document/d/DOCUMENT_ID/`
- `https://docs.google.com/document/d/DOCUMENT_ID`

### Примеры использования

```bash
# Обработка конкретного документа
node run_with_url.js "https://docs.google.com/document/d/1XO0_BqH-e4B-_F4hrzKKuaX6w8CR2IARgvAsfjQnAKA/edit"

# Использование с опцией --url
node run_with_url.js --url "https://docs.google.com/document/d/1XO0_BqH-e4B-_F4hrzKKuaX6w8CR2IARgvAsfjQnAKA/view"

# Если URL не указан, используется документ по умолчанию
node run_with_url.js
```

### Альтернативные способы запуска

```bash
# Запуск через test_runner (старый способ)
node test_runner.js

# Запуск основного скрипта напрямую
node main_script.js
```

## Зависимости

- `pg` - для работы с PostgreSQL
- `dotenv` - для переменных окружения
- `@supabase/supabase-js` - для работы с Supabase

## Возможности

- **Автоматическое извлечение documentId** из URL Google Docs
- **Поддержка различных форматов URL** (edit, view, без суффикса)
- **Парсинг исторических единиц измерения** (золотники, фунты, унции)
- **Конвертация в современные единицы** (граммы, литры)
- **Сохранение в структурированную базу данных** с рецептами и ингредиентами
- **Обработка ошибок** и подробное логирование

## Структура базы данных

Скрипт создает следующие таблицы:

- `recipes` - основная информация о рецептах
- `ingredients` - ингредиенты с количествами и единицами измерения

## Примеры SQL-запросов

```sql
-- Все рецепты
SELECT recipe_number, name FROM drinks_recipes ORDER BY recipe_number;

-- Поиск рецептов с водкой
SELECT name, recipe_number FROM drinks_recipes
WHERE ingredients::text ILIKE '%водка%';

-- Статистика ингредиентов
SELECT * FROM get_ingredient_statistics() LIMIT 10;

-- Поиск по ингредиенту
SELECT * FROM search_recipes_by_ingredient('анис');
```

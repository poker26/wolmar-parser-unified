import { main } from './main_script.js';

// Функция для извлечения documentId из URL Google Docs
function extractDocumentIdFromUrl(url) {
  try {
    // Поддерживаем различные форматы URL Google Docs
    const patterns = [
      /\/document\/d\/([a-zA-Z0-9-_]+)/,  // Стандартный формат
      /\/document\/d\/([a-zA-Z0-9-_]+)\//, // С завершающим слешем
      /\/document\/d\/([a-zA-Z0-9-_]+)\?/, // С параметрами
      /\/document\/d\/([a-zA-Z0-9-_]+)$/   // В конце строки
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }

    throw new Error('Не удалось извлечь documentId из URL. Убедитесь, что URL имеет правильный формат Google Docs.');
  } catch (error) {
    throw new Error(`Ошибка при извлечении documentId: ${error.message}`);
  }
}

// Функция для парсинга аргументов командной строки
function parseCommandLineArgs() {
  const args = process.argv.slice(2);
  const options = {
    googleDocsUrl: null,
    help: false
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--help' || arg === '-h') {
      options.help = true;
    } else if (arg === '--url' || arg === '-u') {
      if (i + 1 < args.length) {
        options.googleDocsUrl = args[i + 1];
        i++; // Пропускаем следующий аргумент
      } else {
        throw new Error('URL не указан после --url');
      }
    } else if (arg.startsWith('--url=')) {
      options.googleDocsUrl = arg.split('=')[1];
    } else if (arg.startsWith('--')) {
      // Неизвестная опция
      console.warn(`⚠️  Неизвестная опция: ${arg}`);
    } else if (!options.googleDocsUrl) {
      // Первый позиционный аргумент - это URL
      options.googleDocsUrl = arg;
    }
  }

  return options;
}

// Основная логика
try {
  const options = parseCommandLineArgs();
  
  if (options.help) {
    console.log(`
🍷 Historical Recipes Parser

Использование:
  node run_with_url.js [URL] [опции]
  node run_with_url.js --url URL [опции]

Аргументы:
  URL                    URL документа Google Docs для обработки

Опции:
  --url, -u URL          URL документа Google Docs
  --help, -h             Показать эту справку

Поддерживаемые форматы URL:
  • https://docs.google.com/document/d/DOCUMENT_ID/edit
  • https://docs.google.com/document/d/DOCUMENT_ID/view
  • https://docs.google.com/document/d/DOCUMENT_ID/
  • https://docs.google.com/document/d/DOCUMENT_ID

Примеры:
  node run_with_url.js https://docs.google.com/document/d/1XO0_BqH-e4B-_F4hrzKKuaX6w8CR2IARgvAsfjQnAKA/edit
  node run_with_url.js --url https://docs.google.com/document/d/1XO0_BqH-e4B-_F4hrzKKuaX6w8CR2IARgvAsfjQnAKA/view
  node run_with_url.js --help

Если URL не указан, используется документ по умолчанию.
    `);
    process.exit(0);
  }

  if (options.googleDocsUrl) {
    // Проверяем и извлекаем documentId
    const documentId = extractDocumentIdFromUrl(options.googleDocsUrl);
    console.log(`📄 Используем переданный URL: ${options.googleDocsUrl}`);
    console.log(`📋 Извлеченный documentId: ${documentId}`);
  } else {
    console.log('📄 URL не указан, используем документ по умолчанию');
  }

  // Передаем извлеченный documentId в функцию main
  const documentId = options.googleDocsUrl ? extractDocumentIdFromUrl(options.googleDocsUrl) : null;
  main(documentId).catch(error => {
    console.error('Необработанная ошибка:', error);
    process.exit(1);
  });
} catch (error) {
  console.error('Ошибка при парсинге аргументов:', error.message);
  console.log('Используйте --help для получения справки');
  process.exit(1);
}

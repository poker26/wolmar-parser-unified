import { main } from './main_script.js';

// Функция для извлечения documentId из URL Google Docs
function extractDocumentIdFromUrl(url) {
  const match = url.match(/\/document\/d\/([a-zA-Z0-9-_]+)/);
  if (match && match[1]) {
    return match[1];
  }
  throw new Error('Не удалось извлечь documentId из URL');
}

// Получаем аргументы командной строки
const args = process.argv.slice(2);
const url = args[0];

if (!url) {
  console.log('Использование: node simple_runner.js <URL_Google_Docs>');
  console.log('Пример: node simple_runner.js https://docs.google.com/document/d/1XO0_BqH-e4B-_F4hrzKKuaX6w8CR2IARgvAsfjQnAKA/edit');
  process.exit(1);
}

try {
  // Извлекаем documentId из URL
  const documentId = extractDocumentIdFromUrl(url);
  console.log(`📄 URL: ${url}`);
  console.log(`📋 DocumentId: ${documentId}`);
  
  // Запускаем основной скрипт с извлеченным documentId
  main(documentId).catch(error => {
    console.error('Ошибка:', error);
    process.exit(1);
  });
} catch (error) {
  console.error('Ошибка при извлечении documentId:', error.message);
  process.exit(1);
}

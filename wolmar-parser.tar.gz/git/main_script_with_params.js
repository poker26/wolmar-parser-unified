#!/usr/bin/env node

// Адаптированный скрипт для прямого подключения к PostgreSQL (Supabase)
// Установка зависимостей: npm install pg dotenv

import pg from 'pg';
import { config } from 'dotenv';
import fs from 'fs/promises';

const { Pool } = pg;

// Загружаем переменные окружения
config();

// Конфигурация базы данных
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'postgres',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || '',
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false
};

// Проверяем наличие переменных окружения
if (!process.env.DB_HOST || !process.env.DB_NAME || !process.env.DB_USER || !process.env.DB_PASSWORD) {
  console.error('❌ Ошибка: Не все переменные окружения настроены.');
  console.log('Создайте файл .env со следующими переменными:');
  console.log('DB_HOST=your-host');
  console.log('DB_NAME=your-database');
  console.log('DB_USER=your-username');
  console.log('DB_PASSWORD=your-password');
  console.log('DB_SSL=true (если используете SSL)');
  process.exit(1);
}

// Функция для извлечения documentId из URL Google Docs
function extractDocumentIdFromUrl(url) {
  try {
    // Поддерживаем различные форматы URL Google Docs
    const patterns = [
      /\/document\/d\/([a-zA-Z0-9-_]+)/,  // Стандартный формат
      /\/document\/d\/([a-zA-Z0-9-_]+)\//, // С завершающим слешем
      /\/document\/d\/([a-zA-Z0-9-_]+)\?/, // С параметрами
      /\/document\/d\/([a-zA-Z0-9-_]+)$/   // В конце строки
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }

    throw new Error('Не удалось извлечь documentId из URL. Убедитесь, что URL имеет правильный формат Google Docs.');
  } catch (error) {
    throw new Error(`Ошибка при извлечении documentId: ${error.message}`);
  }
}

// Функция для парсинга аргументов командной строки
function parseCommandLineArgs() {
  const args = process.argv.slice(2);
  const options = {
    googleDocsUrl: null,
    help: false
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--help' || arg === '-h') {
      options.help = true;
    } else if (arg === '--url' || arg === '-u') {
      if (i + 1 < args.length) {
        options.googleDocsUrl = args[i + 1];
        i++; // Пропускаем следующий аргумент
      } else {
        throw new Error('URL не указан после --url');
      }
    } else if (arg.startsWith('--url=')) {
      options.googleDocsUrl = arg.split('=')[1];
    } else if (arg.startsWith('--')) {
      // Неизвестная опция
      console.warn(`⚠️  Неизвестная опция: ${arg}`);
    } else if (!options.googleDocsUrl) {
      // Первый позиционный аргумент - это URL
      options.googleDocsUrl = arg;
    }
  }

  return options;
}

// Функция для получения текста из Google Docs
async function fetchGoogleDocsText(documentId) {
  const exportUrl = `https://docs.google.com/document/d/${documentId}/export?format=txt`;

  try {
    console.log('📄 Извлекаем текст из Google Docs...');
    
    const response = await fetch(exportUrl);
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const text = await response.text();
    console.log(`📄 Извлечено ${text.length} символов`);
    
    return text;
  } catch (error) {
    console.error('❌ Ошибка доступа к Google Docs:', error.message);
    throw error;
  }
}

// Класс для парсинга исторических рецептов
class HistoricalRecipeParser {
  constructor() {
    this.processed = 0;
    this.errors = 0;
    this.skipped = 0;
  }

  // Парсинг рецептов из текста
  parseRecipes(text) {
    const recipes = [];
    const lines = text.split('\n');
    let currentRecipe = null;
    let inRecipe = false;

    for (const line of lines) {
      const trimmedLine = line.trim();
      
      if (!trimmedLine) continue;

      // Ищем начало рецепта (обычно номер и название)
      if (this.isRecipeStart(trimmedLine)) {
        if (currentRecipe) {
          recipes.push(currentRecipe);
        }
        
        currentRecipe = this.createRecipe(trimmedLine);
        inRecipe = true;
        continue;
      }

      if (inRecipe && currentRecipe) {
        // Добавляем ингредиенты
        if (this.isIngredient(trimmedLine)) {
          const ingredient = this.parseIngredient(trimmedLine);
          if (ingredient) {
            currentRecipe.ingredients.push(ingredient);
          }
        }
        // Добавляем инструкции
        else if (this.isInstruction(trimmedLine)) {
          currentRecipe.instructions.push(trimmedLine);
        }
        // Добавляем описание
        else {
          currentRecipe.description += (currentRecipe.description ? ' ' : '') + trimmedLine;
        }
      }
    }

    // Добавляем последний рецепт
    if (currentRecipe) {
      recipes.push(currentRecipe);
    }

    return recipes;
  }

  // Проверка, является ли строка началом рецепта
  isRecipeStart(line) {
    return /^\d+\.?\s*[А-ЯЁ]/.test(line) || 
           /^[А-ЯЁ][а-яё\s]+рецепт/i.test(line) ||
           /^[А-ЯЁ][а-яё\s]+напиток/i.test(line);
  }

  // Создание нового рецепта
  createRecipe(line) {
    return {
      title: line.replace(/^\d+\.?\s*/, ''),
      description: '',
      ingredients: [],
      instructions: [],
      source: 'Historical Document',
      created_at: new Date().toISOString()
    };
  }

  // Проверка, является ли строка ингредиентом
  isIngredient(line) {
    return /\d+\s*[а-яё]+/i.test(line) && 
           (line.includes('грамм') || line.includes('г') || 
            line.includes('литр') || line.includes('л') ||
            line.includes('стакан') || line.includes('ложка') ||
            line.includes('чашка') || line.includes('унция') ||
            line.includes('фунт') || line.includes('драхма'));
  }

  // Парсинг ингредиента
  parseIngredient(line) {
    try {
      // Извлекаем количество и единицу измерения
      const match = line.match(/(\d+(?:\.\d+)?)\s*([а-яё]+)/i);
      if (match) {
        const amount = parseFloat(match[1]);
        const unit = match[2].toLowerCase();
        
        // Извлекаем название ингредиента
        const ingredientName = line.replace(/\d+(?:\.\d+)?\s*[а-яё]+\s*/i, '').trim();
        
        return {
          name: ingredientName,
          amount: amount,
          unit: this.normalizeUnit(unit),
          original_unit: unit
        };
      }
    } catch (error) {
      console.warn(`⚠️  Ошибка парсинга ингредиента: ${line}`);
    }
    return null;
  }

  // Нормализация единиц измерения
  normalizeUnit(unit) {
    const unitMap = {
      'грамм': 'г',
      'грамма': 'г',
      'граммов': 'г',
      'г': 'г',
      'литр': 'л',
      'литра': 'л',
      'литров': 'л',
      'л': 'л',
      'стакан': 'стакан',
      'стакана': 'стакан',
      'стаканов': 'стакан',
      'ложка': 'ложка',
      'ложки': 'ложка',
      'ложек': 'ложка',
      'чашка': 'чашка',
      'чашки': 'чашка',
      'чашек': 'чашка',
      'унция': 'унция',
      'унции': 'унция',
      'унций': 'унция',
      'фунт': 'фунт',
      'фунта': 'фунт',
      'фунтов': 'фунт',
      'драхма': 'драхма',
      'драхмы': 'драхма',
      'драхм': 'драхма'
    };
    
    return unitMap[unit] || unit;
  }

  // Проверка, является ли строка инструкцией
  isInstruction(line) {
    return line.startsWith('-') || 
           line.startsWith('•') || 
           /^[а-яё]+\s+[а-яё]+/i.test(line);
  }
}

// Функция для создания таблиц и функций в базе данных
async function createTablesAndFunctions(pool) {
  console.log('🏗️  Создаем таблицы и функции в базе данных...');

  // Создаем таблицу рецептов
  await pool.query(`
    CREATE TABLE IF NOT EXISTS recipes (
      id SERIAL PRIMARY KEY,
      title VARCHAR(500) NOT NULL,
      description TEXT,
      instructions TEXT[],
      source VARCHAR(200),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Создаем таблицу ингредиентов
  await pool.query(`
    CREATE TABLE IF NOT EXISTS ingredients (
      id SERIAL PRIMARY KEY,
      recipe_id INTEGER REFERENCES recipes(id) ON DELETE CASCADE,
      name VARCHAR(200) NOT NULL,
      amount DECIMAL(10,3),
      unit VARCHAR(50),
      original_unit VARCHAR(50),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Создаем функцию для обновления updated_at
  await pool.query(`
    CREATE OR REPLACE FUNCTION update_updated_at_column()
    RETURNS TRIGGER AS $$
    BEGIN
      NEW.updated_at = CURRENT_TIMESTAMP;
      RETURN NEW;
    END;
    $$ language 'plpgsql';
  `);

  // Создаем триггер для автоматического обновления updated_at
  await pool.query(`
    DROP TRIGGER IF EXISTS update_recipes_updated_at ON recipes;
    CREATE TRIGGER update_recipes_updated_at
      BEFORE UPDATE ON recipes
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  `);

  console.log('✅ Таблицы и функции созданы');
}

// Функция для сохранения рецепта в базу данных
async function saveRecipeToDatabase(pool, recipe) {
  try {
    // Сохраняем рецепт
    const recipeResult = await pool.query(`
      INSERT INTO recipes (title, description, instructions, source)
      VALUES ($1, $2, $3, $4)
      RETURNING id
    `, [recipe.title, recipe.description, recipe.instructions, recipe.source]);

    const recipeId = recipeResult.rows[0].id;

    // Сохраняем ингредиенты
    for (const ingredient of recipe.ingredients) {
      await pool.query(`
        INSERT INTO ingredients (recipe_id, name, amount, unit, original_unit)
        VALUES ($1, $2, $3, $4, $5)
      `, [recipeId, ingredient.name, ingredient.amount, ingredient.unit, ingredient.original_unit]);
    }

    console.log(`✅ Рецепт "${recipe.title}" сохранен (ID: ${recipeId})`);
  } catch (error) {
    console.error(`❌ Ошибка сохранения рецепта "${recipe.title}":`, error.message);
    throw error;
  }
}

// Основная функция
async function main(googleDocsUrl = null) {
  const pool = new Pool(dbConfig);

  try {
    console.log('🍷 ИЗВЛЕЧЕНИЕ ИСТОРИЧЕСКИХ РЕЦЕПТОВ НАПИТКОВ');
    console.log('='.repeat(60));

    // Проверяем подключение к базе данных
    console.log('🔌 Проверяем подключение к базе данных...');
    const testResult = await pool.query('SELECT NOW()');
    console.log('✅ Подключение к PostgreSQL успешно');

    // Создаем таблицы и функции
    await createTablesAndFunctions(pool);

    // Получаем текст документа
    let documentText;
    
    // Извлекаем documentId из URL или используем переданный параметр
    let documentId;
    if (googleDocsUrl) {
      documentId = extractDocumentIdFromUrl(googleDocsUrl);
      console.log(`📄 Используем переданный URL: ${googleDocsUrl}`);
      console.log(`📋 Извлеченный documentId: ${documentId}`);
    } else {
      // Используем URL по умолчанию, если не передан параметр
      documentId = '1XO0_BqH-e4B-_F4hrzKKuaX6w8CR2IARgvAsfjQnAKA';
      console.log('📄 Используем URL по умолчанию');
    }
    
    documentText = await fetchGoogleDocsText(documentId);

    if (!documentText || documentText.length < 100) {
      throw new Error('Документ слишком короткий или пустой');
    }

    console.log(`📄 Извлечено ${documentText.length} символов`);

    // Парсим рецепты
    const parser = new HistoricalRecipeParser();
    const recipes = parser.parseRecipes(documentText);

    console.log(`🍹 Найдено ${recipes.length} рецептов`);

    // Сохраняем в базу данных
    console.log('💾 Сохраняем рецепты в базу данных...');
    for (let i = 0; i < recipes.length; i++) {
      const recipe = recipes[i];
      console.log(`📝 Сохраняем рецепт ${i + 1}/${recipes.length}: ${recipe.title}`);
      
      await saveRecipeToDatabase(pool, recipe);
    }

    console.log('\n🎉 ОБРАБОТКА ЗАВЕРШЕНА УСПЕШНО!');
    console.log(`📊 Статистика:`);
    console.log(`   • Всего рецептов: ${recipes.length}`);
    console.log(`   • Обработано: ${recipes.length}`);
    console.log(`   • Ошибок: 0`);

  } catch (error) {
    console.error('\n💥 КРИТИЧЕСКАЯ ОШИБКА:', error.message);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

// Запуск
if (import.meta.url === `file://${process.argv[1]}`) {
  try {
    const options = parseCommandLineArgs();
    
    if (options.help) {
      console.log(`
🍷 Historical Recipes Parser

Использование:
  node main_script_with_params.js [URL] [опции]
  node main_script_with_params.js --url URL [опции]

Аргументы:
  URL                    URL документа Google Docs для обработки

Опции:
  --url, -u URL          URL документа Google Docs
  --help, -h             Показать эту справку

Примеры:
  node main_script_with_params.js https://docs.google.com/document/d/1XO0_BqH-e4B-_F4hrzKKuaX6w8CR2IARgvAsfjQnAKA/edit
  node main_script_with_params.js --url https://docs.google.com/document/d/1XO0_BqH-e4B-_F4hrzKKuaX6w8CR2IARgvAsfjQnAKA/edit
  node main_script_with_params.js --help

Если URL не указан, используется документ по умолчанию.
      `);
      process.exit(0);
    }

    main(options.googleDocsUrl).catch(error => {
      console.error('Необработанная ошибка:', error);
      process.exit(1);
    });
  } catch (error) {
    console.error('Ошибка при парсинге аргументов:', error.message);
    console.log('Используйте --help для получения справки');
    process.exit(1);
  }
}

export { main, HistoricalRecipeParser };

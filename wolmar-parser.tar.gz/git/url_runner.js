import fs from 'fs/promises';
import { main } from './main_script_with_params.js';

// Функция для извлечения documentId из URL Google Docs
function extractDocumentIdFromUrl(url) {
  const match = url.match(/\/document\/d\/([a-zA-Z0-9-_]+)/);
  if (match && match[1]) {
    return match[1];
  }
  throw new Error('Не удалось извлечь documentId из URL');
}

// Основная логика
async function runWithUrl() {
  const args = process.argv.slice(2);
  const url = args[0];

  if (!url) {
    console.log('Использование: node url_runner.js <URL_Google_Docs>');
    console.log('Пример: node url_runner.js https://docs.google.com/document/d/1XO0_BqH-e4B-_F4hrzKKuaX6w8CR2IARgvAsfjQnAKA/edit');
    process.exit(1);
  }

  try {
    // Извлекаем documentId из URL для проверки
    const documentId = extractDocumentIdFromUrl(url);
    console.log(`📄 URL: ${url}`);
    console.log(`📋 DocumentId: ${documentId}`);
    
    // Запускаем основной скрипт с переданным URL
    await main(url);
    
  } catch (error) {
    console.error('Ошибка:', error);
    process.exit(1);
  }
}

runWithUrl();

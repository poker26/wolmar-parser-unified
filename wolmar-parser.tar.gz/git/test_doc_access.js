import fetch from 'node-fetch';

async function testDocAccess() {
  const documentId = '15WYaSkpiEzJzC1je8mO1F6_ZBrFRTj-_RHTrLpBQ4ok';
  
  // Тест 1: Прямой доступ к документу
  console.log('Тест 1: Прямой доступ к документу...');
  try {
    const response1 = await fetch(`https://docs.google.com/document/d/${documentId}/edit`);
    console.log('Статус прямого доступа:', response1.status);
  } catch (error) {
    console.log('Ошибка прямого доступа:', error.message);
  }
  
  // Тест 2: Экспорт как текст
  console.log('\nТест 2: Экспорт как текст...');
  try {
    const response2 = await fetch(`https://docs.google.com/document/d/${documentId}/export?format=txt`);
    console.log('Статус экспорта:', response2.status);
    if (response2.ok) {
      const text = await response2.text();
      console.log('Первые 200 символов:', text.substring(0, 200));
    }
  } catch (error) {
    console.log('Ошибка экспорта:', error.message);
  }
  
  // Тест 3: Экспорт как HTML
  console.log('\nТест 3: Экспорт как HTML...');
  try {
    const response3 = await fetch(`https://docs.google.com/document/d/${documentId}/export?format=html`);
    console.log('Статус HTML экспорта:', response3.status);
  } catch (error) {
    console.log('Ошибка HTML экспорта:', error.message);
  }
}

testDocAccess();
